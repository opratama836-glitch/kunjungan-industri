/* ====== EDIT DATA DI SINI ====== */
const TANGGAL_BERANGKAT = new Date("2026-11-19T08:00:00+07:00");

const JADWAL = {
  "Pagi": [
    ["07.00", "Berkumpul dan berangkat", "Cek kehadiran, lalu menuju Jakarta."],
    ["09.00", "Tiba di Museum Bank Indonesia", "Registrasi dan arahan dari pemandu."],
    ["09.30", "Menjelajah galeri museum", "Sejarah uang, perbankan, dan ekonomi Indonesia."]
  ],
  "Siang": [
    ["11.30", "Ishoma", "Makan siang dan salat."],
    ["12.30", "Menuju Bursa Efek Indonesia", "Perjalanan ke kawasan SCBD."],
    ["13.30", "Pengenalan pasar modal", "Penjelasan peran bursa dan cara investasi."]
  ],
  "Sore": [
    ["14.30", "Ruang perdagangan dan galeri BEI", "Layar indeks saham dan edukasi investasi."],
    ["15.30", "Foto bersama dan pulang", "Kembali ke sekolah."]
  ]
};

/* Foto ada di assets/foto/, video di assets/video/ */
const FOTO = [
  {src:"assets/foto/logo-idx.jpg", cap:"Logo IDX di lobi Bursa Efek Indonesia", cat:"Bursa Efek Indonesia"},
  {src:"assets/foto/lantai-bursa.jpg", cap:"Layar indeks saham melingkar di ruang perdagangan", cat:"Bursa Efek Indonesia"},
  {src:"assets/foto/bursa-karbon.jpg", cap:"Prasasti peresmian Bursa Karbon Indonesia", cat:"Bursa Efek Indonesia"},
  {src:"assets/foto/grafik-investasi.jpg", cap:"Grafik pertumbuhan saham, emas, deposito, dan tabungan selama 10 tahun", cat:"Bursa Efek Indonesia"},
  {src:"assets/foto/makin-maju.jpg", cap:"Panel “Makin maju, makin serakah menjajah” dengan globe dunia", cat:"Museum Bank Indonesia"},
  {src:"assets/foto/jalan-menuju-merdeka.jpg", cap:"Panel “Jalan panjang menuju merdeka”", cat:"Museum Bank Indonesia"},
  {src:"assets/foto/cetak-uang.jpg", cap:"Panel tentang pencetakan uang dan inflasi tahun 1958", cat:"Museum Bank Indonesia"},
  {src:"assets/foto/seragam-pandu.jpg", cap:"Koleksi seragam pandu dengan kacu merah putih", cat:"Museum Bank Indonesia"},
  {src:"assets/foto/seragam-putih.jpg", cap:"Koleksi seragam putih dengan bambu dan kain merah", cat:"Museum Bank Indonesia"},
  {src:"assets/foto/seragam-militer.jpg", cap:"Koleksi seragam masa perjuangan dengan sarung pedang", cat:"Museum Bank Indonesia"}
];
const VIDEO = [
  {src:"assets/video/cuplikan.mp4", title:"Cuplikan kunjungan", desc:"Rekaman singkat saat berada di lokasi kunjungan."}
];
const FAQ = [
  ["Apa yang harus dipakai?", "Seragam batik sekolah dan sepatu rapi. Bawa kartu pelajar."],
  ["Boleh membawa ponsel?", "Boleh. Foto hanya di area yang diizinkan pemandu."],
  ["Apa yang bisa dipelajari di Museum Bank Indonesia?", "Sejarah uang, perbankan, dan perjalanan ekonomi Indonesia dari masa kolonial sampai kemerdekaan."],
  ["Apa yang bisa dipelajari di Bursa Efek Indonesia?", "Cara kerja bursa saham, perbedaan produk investasi, dan peran pasar modal."],
  ["Apakah ada tugas setelah kunjungan?", "Biasanya ada laporan singkat dari catatan selama kunjungan. Tanyakan ke guru pendamping."]
];
/* ====== AKHIR DATA ====== */

const $ = (s, el = document) => el.querySelector(s);
const make = (tag, props = {}, kids = []) => {
  const e = Object.assign(document.createElement(tag), props);
  kids.forEach(k => e.append(k)); return e;
};

/* menu mobile */
const burger = $("#burger"), menu = $("#menu");
burger.onclick = () => {
  const open = menu.classList.toggle("open");
  burger.setAttribute("aria-expanded", open);
};
menu.onclick = e => { if (e.target.tagName === "A") { menu.classList.remove("open"); burger.setAttribute("aria-expanded", false); } };

/* link menu aktif saat scroll */
const links = [...document.querySelectorAll("#menu a")];
const spy = new IntersectionObserver(es => es.forEach(en => {
  if (en.isIntersecting) links.forEach(a => a.classList.toggle("active", a.hash === "#" + en.target.id));
}), {rootMargin: "-45% 0px -50% 0px"});
document.querySelectorAll("main section[id]").forEach(s => spy.observe(s));

/* hitung mundur */
function tick() {
  let diff = TANGGAL_BERANGKAT - Date.now();
  if (diff <= 0) { $("#cd-label").textContent = "Kunjungan dilaksanakan pada"; $("#cd").replaceChildren(make("b", {textContent: "19 November 2026"})); $("#cd").style.display = "block"; return; }
  const d = Math.floor(diff / 864e5), h = Math.floor(diff % 864e5 / 36e5),
        m = Math.floor(diff % 36e5 / 6e4), s = Math.floor(diff % 6e4 / 1e3);
  $("#cd-d").textContent = d; $("#cd-h").textContent = h;
  $("#cd-m").textContent = m; $("#cd-s").textContent = s;
}
tick(); setInterval(tick, 1000);

/* jadwal bertab */
const tabs = $("#tabs"), tl = $("#timeline");
function showDay(name) {
  [...tabs.children].forEach(b => b.setAttribute("aria-selected", b.dataset.k === name));
  tl.replaceChildren(...JADWAL[name].map(([t, h, p]) =>
    make("li", {}, [make("time", {textContent: t + " WIB"}), make("h3", {textContent: h}), make("p", {textContent: p})])));
}
Object.keys(JADWAL).forEach(k => {
  const b = make("button", {className: "tab", textContent: k, role: "tab"});
  b.dataset.k = k; b.onclick = () => showDay(k); tabs.append(b);
});
showDay(Object.keys(JADWAL)[0]);

/* galeri + filter */
const gallery = $("#gallery"), filters = $("#filters");
let current = [], idx = 0;
function placeholder(text) { return make("div", {className: "ph", textContent: text}); }
function renderGallery(cat) {
  current = FOTO.filter(f => cat === "Semua" || f.cat === cat);
  gallery.replaceChildren(...current.map((f, i) => {
    const img = make("img", {src: f.src, alt: f.cap, loading: "lazy"});
    const btn = make("button", {className: "shot"}, [img, make("div", {className: "cap", textContent: f.cap})]);
    img.onerror = () => img.replaceWith(placeholder("Foto belum ditambahkan: " + f.src.split("/").pop()));
    btn.onclick = () => openModal(i);
    return btn;
  }));
}
["Semua", ...new Set(FOTO.map(f => f.cat))].forEach((c, i) => {
  const b = make("button", {className: "chip", textContent: c});
  b.setAttribute("aria-pressed", i === 0);
  b.onclick = () => { [...filters.children].forEach(x => x.setAttribute("aria-pressed", x === b)); renderGallery(c); };
  filters.append(b);
});
renderGallery("Semua");

/* video */
$("#videos").replaceChildren(...VIDEO.map(v => {
  const media = make("video", {src: v.src, controls: true, preload: "metadata"});
  media.onerror = () => media.replaceWith(placeholder("Video belum ditambahkan: " + v.src.split("/").pop()));
  return make("article", {className: "vid"}, [media, make("h3", {textContent: v.title}), make("p", {textContent: v.desc})]);
}));

/* lightbox */
const modal = $("#modal"), body = $("#modalBody");
function openModal(i) {
  idx = (i + current.length) % current.length;
  const f = current[idx];
  body.replaceChildren(make("img", {src: f.src, alt: f.cap}), make("p", {textContent: f.cap}));
  modal.hidden = false; document.body.style.overflow = "hidden"; $("#close").focus();
}
const closeModal = () => { modal.hidden = true; document.body.style.overflow = ""; };
$("#close").onclick = closeModal;
$("#prev").onclick = () => openModal(idx - 1);
$("#next").onclick = () => openModal(idx + 1);
modal.onclick = e => { if (e.target === modal) closeModal(); };
document.addEventListener("keydown", e => {
  if (modal.hidden) return;
  if (e.key === "Escape") closeModal();
  if (e.key === "ArrowLeft") openModal(idx - 1);
  if (e.key === "ArrowRight") openModal(idx + 1);
});

/* FAQ */
$("#faqList").replaceChildren(...FAQ.map(([q, a], i) => {
  const btn = make("button", {textContent: q}); btn.setAttribute("aria-expanded", "false"); btn.id = "q" + i;
  const panel = make("div", {className: "a"}, [make("div", {}, [make("p", {textContent: a})])]);
  btn.onclick = () => btn.setAttribute("aria-expanded", btn.getAttribute("aria-expanded") !== "true");
  return make("div", {className: "q"}, [btn, panel]);
}));
