# Website Kunjungan Industri

Website statis (HTML, CSS, JavaScript) untuk kunjungan industri ke Museum Bank Indonesia dan Bursa Efek Indonesia.

## Cara mengubah isi
- Teks info: `index.html`
- Jadwal, daftar foto, video, FAQ, dan tanggal: bagian atas `script.js`
- Foto: taruh di `assets/foto/`, video di `assets/video/`

## Cara menjalankan
Buka `index.html` di browser.

## Hosting gratis
GitHub repo → Settings → Pages → Branch `main` / root → Save.
